package com.example.facturacion.presentation.login;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;

import com.example.facturacion.logic.Usuario;
import com.example.facturacion.security.UserDetailsImp;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/login")
public class Login {
    @PostMapping("/login")
    public Usuario login(@RequestBody Usuario form,  HttpServletRequest request) {
        try {
            request.login(form.getIdentificacion(), form.getContrasena());
        } catch (ServletException e) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        }
        Authentication auth = (Authentication) request.getUserPrincipal();
        Usuario user = ((UserDetailsImp) auth.getPrincipal()).getUser();
        return new Usuario(user.getIdentificacion(), null, user.getRol());
    }

    @PostMapping("/logout")
    public void logout(HttpServletRequest request) {
        try {
            request.logout();
        } catch (ServletException e) {
        }
    }

    @GetMapping("/current-user")
    public Usuario getCurrentUser(@AuthenticationPrincipal UserDetailsImp user) {
        return new Usuario(user.getUser().getIdentificacion(), null, user.getUser().getRol());
    }
}
