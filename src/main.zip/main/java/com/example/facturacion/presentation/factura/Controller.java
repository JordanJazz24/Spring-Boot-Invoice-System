//package com.example.facturacion.presentation.factura;
//
//import com.example.facturacion.logic.*;
//import jakarta.servlet.http.HttpSession;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//
//import java.util.ArrayList;
//import java.util.Collection;
//import java.util.List;
//
//@org.springframework.stereotype.Controller("FacturaController")
//public class Controller {
//    @Autowired
//    private Service service;
//
//    @GetMapping("/presentation/factura/show")
//    public String showFacturas(Model model, HttpSession session) {
//        if (session.getAttribute("cliente") != null) {
//            session.removeAttribute("cliente");
//        }
//        // Obtener el proveedor de la sesión
//        Proveedor proveedor = (Proveedor) session.getAttribute("proveedor");
//
//        //buscar los detalles de las facturas
//        Iterable<Detalle> detallesList = service.getDetalles();
//        if (detallesList == null) {
//            detallesList = new ArrayList<>();
//        }
//
//        // Agregar las listas al modelo
//        model.addAttribute("detalleList", detallesList);
//
//        return "/presentation/factura/View";
//    }
//
//    @GetMapping("/presentation/facturacion/show")
//    public String showFacturacion(Model model, HttpSession session) {
//        // Obtener el proveedor de la sesión
//        Proveedor proveedor = (Proveedor) session.getAttribute("proveedor");
//        model.addAttribute("proveedor", proveedor);
//        if (session.getAttribute("cliente") == null) {
//            model.addAttribute("cliente", new Cliente());
//            if (session.getAttribute("detalles") == null) {
//                model.addAttribute("detallesList", new ArrayList<>());
//            }else {
//                model.addAttribute("detallesList", session.getAttribute("detalles"));
//            }
//            //
//        } else {
//            model.addAttribute("cliente", session.getAttribute("cliente"));
//            Iterable<Detalle> detalles = (Iterable<Detalle>) session.getAttribute("detalles");
//            if (detalles != null) {
//                model.addAttribute("detallesList", detalles);
//            } else {
//                model.addAttribute("detallesList", new ArrayList<>());
//            }
//        }
//
//        return "/presentation/facturacion/View";
//    }
//
//    @GetMapping("/presentation/facturacion/validar")
//    public String validarCliente(@ModelAttribute Cliente cliente, HttpSession session, Model model) {
//
//        Cliente clienteDB = service.clienteRead(cliente.getIdentificacion());
//        if (clienteDB == null) {
//            return "/presentation/facturacion/show";
//        }
//        session.setAttribute("cliente", clienteDB); //guardar el cliente en la sesión
//        model.addAttribute("cliente", clienteDB);
//        Proveedor proveedor = (Proveedor) session.getAttribute("proveedor");
//        model.addAttribute("proveedor", proveedor);
//
//        return "redirect:/presentation/facturacion/show";
//    }
//
//
//    @GetMapping("/presentation/facturacion/agregar")
//    public String agregaProducto(@ModelAttribute Producto producto, HttpSession session, Model model) {
//
//        Producto productoDB = service.productoRead(producto.getCodigo());
//        if (productoDB == null) {
//            return "/presentation/facturacion/show";
//        }
//        List<Detalle> detalles ;
//        if (session.getAttribute("detalles") != null) {
//            detalles = (List<Detalle>) session.getAttribute("detalles");
//           if(detalles.stream().anyMatch(detalle -> detalle.getProductoByIdProducto().getId() == productoDB.getId())){
//               Detalle detalle = detalles.stream().filter(detalle1 -> detalle1.getProductoByIdProducto().getId() == productoDB.getId()).findFirst().get();
//               detalle.setCantidad(detalle.getCantidad() + 1);
//               detalle.setMontoTotal(detalle.getMontoTotal().add(productoDB.getPrecio()));
//               session.setAttribute("detalles", detalles);
//               model.addAttribute("detallesList", detalles);
//               return "redirect:/presentation/facturacion/show";}
//            Detalle detalle = new Detalle();
//            detalle.setProductoByIdProducto(productoDB);
//            detalle.setCantidad(1);
//            detalle.setMontoTotal(productoDB.getPrecio());
//            detalles.add(detalle);
//            session.setAttribute("detalles", detalles);
//        } else {
//            detalles = new ArrayList<>();
//            Detalle detalle = new Detalle();
//            detalle.setProductoByIdProducto(productoDB);
//            detalle.setCantidad(1);
//            detalle.setMontoTotal(productoDB.getPrecio());
//            detalles.add(detalle);
//            session.setAttribute("detalles", detalles);
//        }
//        model.addAttribute("detallesList", detalles);
//        return "redirect:/presentation/facturacion/show";
//
//    }
//
//
//    @GetMapping("/presentation/facturacion/crear")
//    public String crearFactura(HttpSession session, Model model) {
//        Proveedor proveedor = (Proveedor) session.getAttribute("proveedor");
//        Cliente cliente = (Cliente) session.getAttribute("cliente");
//        List<Detalle> detalles = (List<Detalle>) session.getAttribute("detalles");
//        Factura factura = new Factura();
//        factura.setClienteByIdCliente(cliente);
//        factura.setProveedorByIdProveedor(proveedor);
//        service.createFactura(factura);
//        for (Detalle detalle : detalles) {
//            detalle.setFacturaByIdFactura(factura);
//            service.createDetalle(detalle);
//        }
//        session.removeAttribute("cliente");
//        session.removeAttribute("detalles");
//        return "redirect:/presentation/factura/show";
//    }
//
//
//    @GetMapping("/presentation/facturacion/agregarCliente/")
//    public String agregarCliente(@ModelAttribute Cliente cliente, HttpSession session, Model model) {
//Cliente clienteDB = service.clienteRead(cliente.getIdentificacion());
//    session.setAttribute("cliente", clienteDB);
//        return "redirect:/presentation/facturacion/show";
//    }
//
//
//
//}
