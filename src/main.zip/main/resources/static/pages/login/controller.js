document.addEventListener("DOMContentLoaded",loaded);

async function loaded(event) {
    try{ await menu();} catch(error){return;}
}